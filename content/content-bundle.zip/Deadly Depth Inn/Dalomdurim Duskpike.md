---
name: Dalomdurim Duskpike
AssociatedGroup: 
Gender: Male
Race: Dwarf
Age: 197
Class: [[Investigator]] 
Alignment: 
Character-Role: 
---

> [!infobox]
> # `=this.name`
> ![[Dalomdurim Duskpike.png|cover hsmall]]
> [[Dalomdurim Duskpike.png|Show To Players]]
> ###### Basic Information
> Type |  Stat |
> ---|---|
> Home | [[Suzail]] |
> Group | `=link(this.AssociatedGroup)` |
> Sex | `=this.gender` |
> Race | `=this.race` |
> Age | `=this.age` |
> Condition | Healthy |
> ###### Rules Info
> Type |  Stat |
> ---|---|
> Alignment | `=this.alignment` |
> Class | `=this.class` |
> Character Role | `=this.character-role` |
> ###### Relationships
> Type |  Stat |
> ---|---|
> Related To | Testing |
# `=this.name`
## Profile
**Appearance Traits**: Stylish, Ugly, Beautiful, Diminutive, Disheveled, Filthy, Flabby, Hulking, Muscular, Ornate, Pristine, Slender, Tasteless, Towering, Unadorned

**Social Traits**: Bossy, Cruel, Dependable, Dishonest, Friendly, Generous, Helpful, Honest, Impartial, Loyal, Peaceful, Quiet, Secretive, Selfish, Stingy, Suspicious, Talkative, Tolerant, Trusting, Unfriendly, Selfless, Deferential, Demanding, Forthcoming, Intolerant, Lenient, Uncooperative, Unfair, Unfaithful, Unreliable, Violent

> [!info] Statblock
> ```statblock
> name: Individual
> monster: Commoner
> columns: 1
> ```

```encounter-table
name: Individual
creatures:
 - 1: Commoner
```

## Story
Placeholder

## Motivation and Philosophy
**Mental Traits**: Ambitious, Cautious, Complacent, Courageous, Cowardly, Decisive, Impatient, Independent, Intelligent, Religious, Skillful, Stupid, Superstitious, Tenacious, Adaptive, Analytical, Creative, Patient, Perceptive, Conformist, Emotional, Inattentive, Incompetent, Indecisive, Reckless, Secular, Skeptical, Uninventive

Placeholder

## Personal Life
Placeholder

## Professional Life
**Expertise**: Administrative, Artist, Counselor, Crafter, Criminal, Engineer, Entertainer, Healer, Laborer, Leader, Merchant, Other, Outdoorsman, Protector, Researcher, Scholar, Services, Transporter, Warrior

Placeholder

## Other Endeavors
Placeholder

## Possessions
**Special Equipment**: Placeholder

Placeholder

## Resources
**Status Traits**: Lucky, Popular, Influential, Anonymous, Disreputable, Famous, Helpless, Irrelevant, Isolated, Lower-class, Poor, Powerful, Reputable, Uneducated, Unpopular, Upper-class, Wealthy, Well-connected, Well-educated

Placeholder

## Abilities
**Physical Traits**: Clumsy, Quick, Weak, Conspicuous, Fragile, Graceful, Ponderous, Stealthy, Strong, Tough

Placeholder

## Methods
**Personality Traits**: Anxious, Calm, Charming, Cheerful, Childish, Energetic, Enthusiastic, Funny, Gentle, Humble, Impolite, Mature, Optimistic, Pessimistic, Proud, Respectful, Sensitive, Eccentric, Smooth, Articulate, Subtle, Apathetic, Awkward, Caring, Depressed, Dull, Humorless, Incoherent, Listless, Overt, Repulsive, Savvy, Thick-skinned, Wrathful, Cold, Naïve

Placeholder

## Background
**Birth Date**: Monday, 1 January -20000 12:00:00 AM

**Marriage Date**: Monday, 1 January -20000 12:00:00 AM

**Death Date**: Monday, 1 January -20000 12:00:00 AM

Placeholder

## Additional Details
Placeholder


