---
banner: "![[HOTDQ Banner.png]]"
---
---
banner: "![[HOTDQ Banner.png]]"
banner_x: 0.5
---

# Deadly Depth Inn

| ![[Northern Faerun Map.jpg\|grid]] | ![[JourneyBoard.png\|grid]] | ![[GreenestLogo.png\|grid]]         | ![[PartyLogo.jpg\|grid]] | 
| ---------------------------------- | --------------------------- | ----------------------------------- | ------------------------ |
| [[Faerun]]                         | [[The Journey Board]]       | [[Chapter 1 - Greenest in Flames]] |  [[1. The Party/Deadly Depth Inn/Deadly Depth Inn\|Character Sheets]]                        |


```dataviewjs

dv.span("**💀🧙‍♂️🧙‍♀️ D&D Session 🧙‍♀️🧙‍♂️💀**")

const calendarData = {
    colors: {
        blue: ["#DB0F07", "#FF8C02","#FF7800", "#E86100", "#64AD62","#429B46","#1A8828"]
    },
    entries: [],
    showCurrentDayBorder: false
}

for(let page of dv.pages('"2. Session Journals/Deadly Depth Inn"').where(p=>p.players)){
    calendarData.entries.push({
        date: page.sessionDate, // (required) Format YYYY-MM-DD
        intensity: page.players,
        content: await dv.span(`[](${page.file.name})`), //for hover preview
    })  
}

renderHeatmapCalendar(this.container, calendarData)

```

```dataview
table Player, Class, Race, level, Role
from "1. The Party/Deadly Depth Inn"
where (Role = "Player")
```


```button
name New Magic Item
type note(NewMagicItem, split) template
action TemplateMagicItem
templater true
```
^button-NewMagicItemID

```button
name New NPC
type note(NewNPC, split) template
action TemplateNPC
templater true
```
^button-NewNPCID

```button
name New Location
type note(NewLocation, split) template
action TemplateSettlement
templater true
```
^button-NewLocationID
# Recently Modified Notes
```dataview
TABLE WITHOUT ID
    link(file.path, file.folder + " / " + file.name) AS "Note",
    file.mtime AS "Last modified"
FROM "/"
WHERE file.mtime >= date(today) - dur(30 days)
AND file.name != this.file.name
    AND !contains(file.path, "z_Assets")
    AND !contains(file.path, "Inline Scripts")
    AND !contains(file.path, "z_Templates")
    AND !contains(file.path, "daily notes")
    AND !contains(file.path, "BRAT")
SORT file.mtime DESC
LIMIT 10
```

