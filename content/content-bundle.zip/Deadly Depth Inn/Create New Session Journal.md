---

database-plugin: basic

---

%% dbfolder:yaml
name: Session Journals
description: Notes that document previous sessions.
columns:
  __file__:
    key: __file__
    id: __file__
    input: markdown
    label: File
    accessorKey: __file__
    isMetadata: true
    skipPersist: false
    isDragDisabled: false
    csvCandidate: true
    accessor: __file__
    position: 1
    width: 150
    isHidden: false
    sortIndex: -1
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  __created__:
    key: __created__
    id: __created__
    input: calendar_time
    label: Created
    accessorKey: __created__
    isMetadata: true
    isDragDisabled: false
    skipPersist: false
    csvCandidate: true
    accessor: __created__
    position: 4
    width: 195
    isHidden: false
    sortIndex: -1
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  __modified__:
    key: __modified__
    id: __modified__
    input: calendar_time
    label: Modified
    accessorKey: __modified__
    isMetadata: true
    isDragDisabled: false
    skipPersist: false
    csvCandidate: true
    accessor: __modified__
    position: 5
    width: 190
    isHidden: false
    sortIndex: -1
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  sessionDate:
    input: calendar
    key: sessionDate
    accessor: sessionDate
    label: sessionDate
    position: 2
    skipPersist: false
    accessorKey: sessionDate
    width: 150
    isHidden: false
    sortIndex: -1
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
  players:
    input: number
    accessor: players
    key: players
    label: players
    position: 3
    skipPersist: false
    accessorKey: players
    width: 150
    isHidden: false
    sortIndex: -1
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
  type:
    input: select
    accessorKey: type
    key: type
    label: type
    position: 100
    width: 150
    skipPersist: false
    isHidden: false
    sortIndex: -1
    options:
      - { label: "Session Journal", backgroundColor: "hsl(221, 95%, 90%)"}
      - { label: "sessionjournal", backgroundColor: "hsl(109, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
  sessionstatus:
    input: select
    accessorKey: sessionstatus
    key: sessionstatus
    label: sessionstatus
    position: 100
    skipPersist: false
    isHidden: false
    width: 168
    sortIndex: -1
    options:
      - { label: "Cancelled", backgroundColor: "hsl(197, 95%, 90%)"}
      - { label: "Occured", backgroundColor: "hsl(57, 95%, 90%)"}
      - { label: "Planned", backgroundColor: "hsl(233, 95%, 90%)"}
    config:
      enable_media_view: true
      media_width: 100
      media_height: 100
      isInline: false
      source_data: current_folder
      task_hide_completed: true
config:
  enable_show_state: false
  group_folder_column: 
  remove_field_when_delete_column: true
  show_metadata_created: true
  show_metadata_modified: true
  source_data: current_folder
  source_form_result: root
  cell_size: compact
  sticky_first_column: false
  show_metadata_tasks: false
  frontmatter_quote_wrap: false
  row_templates_folder: /
  current_row_template: 
  show_metadata_inlinks: false
  show_metadata_outlinks: false
  source_destination_path: /
  pagination_size: 100
  formula_folder_path: /
  inline_default: false
  inline_new_position: top
  date_format: yyyy-MM-dd
  datetime_format: "yyyy-MM-dd HH:mm:ss"
  remove_empty_folders: false
  automatically_group_files: false
  hoist_files_with_empty_attributes: true
  enable_js_formulas: false
filters:
  enabled: true
  conditions:
      - field: type
        operator: CONTAINS
        value: Session Journal
%%