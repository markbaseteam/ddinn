---
tags: [timeline, SessionJournals]
---

<div
      class='ob-timelines'
      data-date='144-43-49-00'
      data-title='dd-mm-yyy desc'
      data-class='orange'
      data-img = '\z_Assets\ImagePlaceholder.png'
      data-type='range'
      data-end="2000-10-20-00">
    Enter text to display here.
</div>

## Characters 
 
**Name.** Description. 
 
**Name.** Description. 
 
**Name.** Description. 
 
**Name.** Description. 
 
## Session Overview 
 
Brief session overview.

## Key Learnings
* Description of any important information that the party learned.
* 
* 
*
   
## Who Did They Meet?
 
**Name.** Description 
 
**Name.** Description 
 
**Name.** Description 
 
**Name.** Description 
 
## Items Of Importance
 
* Description 
* 
* 
*
## What Worked 
 
* Small description. 
* 
* 
* 
* 